# AI Prompts Used

The following prompts were used to get assistance for specific parts of this project.

---

**Prompt 1 — Concurrent Checkout Handling**
> "I am building a library management system in Go with SQLite. Multiple students can try to checkout the same book at the same time. The book has limited physical copies. How do I make sure two students don't both get the last copy simultaneously? What transaction approach should I use in SQLite?"

---

**Prompt 2 — Reservation Queue Design**
> "How should I design a FIFO reservation queue in SQLite for a library system? When all copies of a book are checked out, students should be able to queue up. When a book is returned, the first person in the queue should automatically get it. How do I implement this atomically so the queue order is always correct?"

---

**Prompt 3 — Automatic Fine Calculation on Return**
> "In Go, how do I calculate the number of days between two time.Time values and round up to the nearest day? I want to charge a fine of ₹5 per started day for late returns in a library system."

---

**Prompt 4 — Writing Concurrent Tests in Go**
> "How do I write a Go test using httptest that simulates 30 goroutines all trying to checkout the same book at exactly the same time? I want to verify that only 3 checkouts succeed when there are 3 copies, with no duplicate checkouts."
