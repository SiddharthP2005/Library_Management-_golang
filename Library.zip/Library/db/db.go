package db

import (
	"database/sql"
	"log"

	_ "modernc.org/sqlite"
)

var DB *sql.DB

func Init(path string) {
	var err error
	DB, err = sql.Open("sqlite", path)
	if err != nil {
		log.Fatalf("failed to open database: %v", err)
	}
	if _, err = DB.Exec(`PRAGMA journal_mode=WAL;`); err != nil {
		log.Fatalf("WAL pragma: %v", err)
	}
	if _, err = DB.Exec(`PRAGMA foreign_keys=ON;`); err != nil {
		log.Fatalf("FK pragma: %v", err)
	}
	// Single writer — prevents SQLite "database is locked" under concurrency
	DB.SetMaxOpenConns(1)
	migrate()
	log.Println("Database initialised at", path)
}

func migrate() {
	schema := `
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('librarian','student')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    isbn TEXT NOT NULL UNIQUE,
    genre TEXT NOT NULL DEFAULT 'General',
    description TEXT NOT NULL DEFAULT '',
    added_by INTEGER NOT NULL REFERENCES users(id),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS book_copies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    copy_no TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'available'
           CHECK(status IN ('available','checked_out','reserved','lost')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(book_id, copy_no)
);
CREATE TABLE IF NOT EXISTS checkouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    copy_id INTEGER NOT NULL REFERENCES book_copies(id),
    user_id INTEGER NOT NULL REFERENCES users(id),
    checked_out_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    due_date DATETIME NOT NULL,
    returned_at DATETIME,
    fine_amount REAL NOT NULL DEFAULT 0.0,
    fine_paid INTEGER NOT NULL DEFAULT 0 CHECK(fine_paid IN (0,1))
);
CREATE TABLE IF NOT EXISTS reservations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id),
    status TEXT NOT NULL DEFAULT 'waiting'
           CHECK(status IN ('waiting','fulfilled','cancelled','expired')),
    reserved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    fulfilled_at DATETIME,
    UNIQUE(book_id, user_id, status)
);
CREATE INDEX IF NOT EXISTS idx_copies_book       ON book_copies(book_id);
CREATE INDEX IF NOT EXISTS idx_copies_status     ON book_copies(status);
CREATE INDEX IF NOT EXISTS idx_checkouts_user    ON checkouts(user_id);
CREATE INDEX IF NOT EXISTS idx_checkouts_copy    ON checkouts(copy_id);
CREATE INDEX IF NOT EXISTS idx_reservations_book ON reservations(book_id, status);
CREATE INDEX IF NOT EXISTS idx_reservations_user ON reservations(user_id);
`
	if _, err := DB.Exec(schema); err != nil {
		log.Fatalf("migration failed: %v", err)
	}
}
