package middleware

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"
)

type contextKey string

const UserIDKey contextKey = "userID"
const UserRoleKey contextKey = "userRole"

var tokenSecret = func() string {
	if s := os.Getenv("TOKEN_SECRET"); s != "" {
		return s
	}
	return "library-mgmt-secret-2026"
}()

type tokenPayload struct {
	UserID    int64  `json:"user_id"`
	UserRole  string `json:"role"`
	ExpiresAt int64  `json:"exp"`
}

func GenerateToken(userID int64, role string) (string, error) {
	payload := tokenPayload{UserID: userID, UserRole: role, ExpiresAt: time.Now().Add(24 * time.Hour).Unix()}
	data, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}
	encoded := base64.URLEncoding.EncodeToString(data)
	return encoded + "." + sign(encoded), nil
}

func verifyToken(token string) (*tokenPayload, bool) {
	parts := strings.SplitN(token, ".", 2)
	if len(parts) != 2 || sign(parts[0]) != parts[1] {
		return nil, false
	}
	data, err := base64.URLEncoding.DecodeString(parts[0])
	if err != nil {
		return nil, false
	}
	var p tokenPayload
	if err := json.Unmarshal(data, &p); err != nil || time.Now().Unix() > p.ExpiresAt {
		return nil, false
	}
	return &p, true
}

func sign(data string) string {
	h := hmac.New(sha256.New, []byte(tokenSecret))
	h.Write([]byte(data))
	return base64.URLEncoding.EncodeToString(h.Sum(nil))
}

func Authenticate(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		if !strings.HasPrefix(auth, "Bearer ") {
			http.Error(w, `{"error":"missing Authorization header"}`, http.StatusUnauthorized)
			return
		}
		p, ok := verifyToken(strings.TrimPrefix(auth, "Bearer "))
		if !ok {
			http.Error(w, `{"error":"invalid or expired token"}`, http.StatusUnauthorized)
			return
		}
		ctx := context.WithValue(r.Context(), UserIDKey, p.UserID)
		ctx = context.WithValue(ctx, UserRoleKey, p.UserRole)
		next(w, r.WithContext(ctx))
	}
}

func GetUserID(r *http.Request) int64 {
	v := r.Context().Value(UserIDKey)
	if v == nil {
		return 0
	}
	return v.(int64)
}

func GetUserRole(r *http.Request) string {
	v := r.Context().Value(UserRoleKey)
	if v == nil {
		return ""
	}
	return v.(string)
}

func GetPathID(r *http.Request) (int64, bool) {
	parts := strings.Split(strings.TrimSuffix(r.URL.Path, "/"), "/")
	if len(parts) == 0 {
		return 0, false
	}
	id, err := strconv.ParseInt(parts[len(parts)-1], 10, 64)
	return id, err == nil
}

func GetSegmentID(r *http.Request, segment string) (int64, bool) {
	parts := strings.Split(strings.TrimSuffix(r.URL.Path, "/"), "/")
	for i, p := range parts {
		if p == segment && i+1 < len(parts) {
			id, err := strconv.ParseInt(parts[i+1], 10, 64)
			return id, err == nil
		}
	}
	return 0, false
}
