package handlers

import (
	"encoding/json"
	"net/http"

	"library-management/middleware"
	"library-management/models"
)

type bookRequest struct {
	Title       string `json:"title"`
	Author      string `json:"author"`
	ISBN        string `json:"isbn"`
	Genre       string `json:"genre"`
	Description string `json:"description"`
	Copies      int    `json:"copies"` // number of physical copies to add
}

// Books handles GET/POST /api/books
func Books(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		listBooks(w, r)
	case http.MethodPost:
		middleware.Authenticate(createBook)(w, r)
	default:
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
	}
}

// BookByID handles GET/DELETE /api/books/:id
func BookByID(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		getBook(w, r)
	case http.MethodDelete:
		middleware.Authenticate(deleteBook)(w, r)
	default:
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
	}
}

func listBooks(w http.ResponseWriter, r *http.Request) {
	books, err := models.ListBooks()
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch books")
		return
	}
	if books == nil {
		books = []models.Book{}
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{"books": books, "count": len(books)})
}

func getBook(w http.ResponseWriter, r *http.Request) {
	id, ok := middleware.GetPathID(r)
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid book ID")
		return
	}
	book, err := models.GetBookByID(id)
	if err != nil {
		writeError(w, http.StatusNotFound, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, book)
}

func createBook(w http.ResponseWriter, r *http.Request) {
	if middleware.GetUserRole(r) != "librarian" {
		writeError(w, http.StatusForbidden, "only librarians can add books")
		return
	}
	var req bookRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON")
		return
	}
	if req.Title == "" || req.Author == "" || req.ISBN == "" {
		writeError(w, http.StatusBadRequest, "title, author, and isbn are required")
		return
	}
	if req.Copies <= 0 {
		req.Copies = 1
	}
	if req.Genre == "" {
		req.Genre = "General"
	}
	book, err := models.CreateBook(req.Title, req.Author, req.ISBN, req.Genre, req.Description,
		middleware.GetUserID(r), req.Copies)
	if err != nil {
		writeError(w, http.StatusConflict, "failed to add book: "+err.Error())
		return
	}
	writeJSON(w, http.StatusCreated, book)
}

func deleteBook(w http.ResponseWriter, r *http.Request) {
	if middleware.GetUserRole(r) != "librarian" {
		writeError(w, http.StatusForbidden, "only librarians can delete books")
		return
	}
	id, ok := middleware.GetPathID(r)
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid book ID")
		return
	}
	if err := models.DeleteBook(id); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to delete book")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"message": "book deleted"})
}
