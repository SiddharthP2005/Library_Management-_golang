package handlers

import (
	"errors"
	"net/http"

	"library-management/middleware"
	"library-management/models"
)

// Reserve handles POST /api/books/:id/reserve
func Reserve(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	bookID, ok := middleware.GetSegmentID(r, "books")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid book ID")
		return
	}
	// Ensure the book exists
	book, err := models.GetBookByID(bookID)
	if err != nil {
		writeError(w, http.StatusNotFound, "book not found")
		return
	}
	// If the book has available copies, suggest checkout instead
	if book.Available > 0 {
		writeError(w, http.StatusBadRequest, "book is available — use POST /api/books/:id/checkout instead")
		return
	}

	res, err := models.CreateReservation(bookID, middleware.GetUserID(r))
	if err != nil {
		if errors.Is(err, models.ErrAlreadyReserved) {
			writeError(w, http.StatusConflict, err.Error())
		} else {
			writeError(w, http.StatusInternalServerError, err.Error())
		}
		return
	}
	writeJSON(w, http.StatusCreated, map[string]interface{}{
		"message":        "reservation created",
		"reservation_id": res.ID,
		"book_title":     book.Title,
		"queue_position": res.QueuePos,
		"status":         "waiting",
	})
}

// CancelReservation handles DELETE /api/reservations/:id
func CancelReservation(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodDelete {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	id, ok := middleware.GetSegmentID(r, "reservations")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid reservation ID")
		return
	}
	if err := models.CancelReservation(id, middleware.GetUserID(r)); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"message": "reservation cancelled"})
}

// MyReservations handles GET /api/reservations/me
func MyReservations(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	list, err := models.ListUserReservations(middleware.GetUserID(r))
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch reservations")
		return
	}
	if list == nil {
		list = []models.Reservation{}
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{"reservations": list, "count": len(list)})
}

// BookQueue handles GET /api/books/:id/queue (librarian view of waiting list)
func BookQueue(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if middleware.GetUserRole(r) != "librarian" {
		writeError(w, http.StatusForbidden, "librarian access only")
		return
	}
	bookID, ok := middleware.GetSegmentID(r, "books")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid book ID")
		return
	}
	list, err := models.ListBookReservations(bookID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch queue")
		return
	}
	if list == nil {
		list = []models.Reservation{}
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{
		"book_id": bookID,
		"queue":   list,
		"waiting": len(list),
	})
}
