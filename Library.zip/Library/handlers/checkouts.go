package handlers

import (
	"errors"
	"net/http"

	"library-management/middleware"
	"library-management/models"
)

// Checkout handles POST /api/books/:id/checkout
func Checkout(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	bookID, ok := middleware.GetSegmentID(r, "books")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid book ID")
		return
	}
	userID := middleware.GetUserID(r)

	co, err := models.CheckoutBook(bookID, userID)
	if err != nil {
		switch {
		case errors.Is(err, models.ErrNoCopyAvailable):
			writeError(w, http.StatusConflict, "no copy available — use POST /api/books/:id/reserve to join the queue")
		case errors.Is(err, models.ErrAlreadyCheckedOut):
			writeError(w, http.StatusConflict, err.Error())
		default:
			writeError(w, http.StatusInternalServerError, err.Error())
		}
		return
	}
	writeJSON(w, http.StatusCreated, map[string]interface{}{
		"message":        "book checked out successfully",
		"checkout_id":    co.ID,
		"copy_no":        co.CopyNo,
		"due_date":       co.DueDate,
		"loan_days":      models.CheckoutDays,
		"fine_per_day":   models.FinePerDay,
	})
}

// Return handles POST /api/checkouts/:id/return
func Return(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	checkoutID, ok := middleware.GetSegmentID(r, "checkouts")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid checkout ID")
		return
	}
	userID := middleware.GetUserID(r)

	co, err := models.ReturnBook(checkoutID, userID)
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	resp := map[string]interface{}{
		"message":     "book returned successfully",
		"checkout_id": co.ID,
		"returned_at": co.ReturnedAt,
		"fine_amount": co.FineAmount,
	}
	if co.FineAmount > 0 {
		resp["fine_message"] = "you have an outstanding fine — pay via POST /api/checkouts/:id/pay-fine"
	}
	writeJSON(w, http.StatusOK, resp)
}

// MyCheckouts handles GET /api/checkouts/me
func MyCheckouts(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	userID := middleware.GetUserID(r)
	list, err := models.ListUserCheckouts(userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch checkouts")
		return
	}
	if list == nil {
		list = []models.Checkout{}
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{"checkouts": list, "count": len(list)})
}

// AllCheckouts handles GET /api/checkouts (librarian only)
func AllCheckouts(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	if middleware.GetUserRole(r) != "librarian" {
		writeError(w, http.StatusForbidden, "librarian access only")
		return
	}
	list, err := models.ListAllCheckouts()
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch checkouts")
		return
	}
	if list == nil {
		list = []models.Checkout{}
	}
	writeJSON(w, http.StatusOK, map[string]interface{}{"active_checkouts": list, "count": len(list)})
}

// PayFine handles POST /api/checkouts/:id/pay-fine
func PayFine(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	checkoutID, ok := middleware.GetSegmentID(r, "checkouts")
	if !ok {
		writeError(w, http.StatusBadRequest, "invalid checkout ID")
		return
	}
	if err := models.PayFine(checkoutID, middleware.GetUserID(r)); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"message": "fine paid successfully"})
}

// MyFines handles GET /api/fines/me
func MyFines(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	summary, err := models.GetUserFines(middleware.GetUserID(r))
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to fetch fines")
		return
	}
	writeJSON(w, http.StatusOK, summary)
}
