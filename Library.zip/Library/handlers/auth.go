package handlers

import (
	"encoding/json"
	"net/http"

	"library-management/middleware"
	"library-management/models"
)

type registerRequest struct {
	Name     string `json:"name"`
	Email    string `json:"email"`
	Password string `json:"password"`
	Role     string `json:"role"`
}

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

func Register(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req registerRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON")
		return
	}
	if req.Name == "" || req.Email == "" || req.Password == "" {
		writeError(w, http.StatusBadRequest, "name, email, and password are required")
		return
	}
	if req.Role != "librarian" && req.Role != "student" {
		req.Role = "student"
	}
	user, err := models.CreateUser(req.Name, req.Email, req.Password, req.Role)
	if err != nil {
		writeError(w, http.StatusConflict, "email already registered")
		return
	}
	token, err := middleware.GenerateToken(user.ID, user.Role)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "token generation failed")
		return
	}
	writeJSON(w, http.StatusCreated, map[string]interface{}{"token": token, "user": user})
}

func Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		writeError(w, http.StatusMethodNotAllowed, "method not allowed")
		return
	}
	var req loginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON")
		return
	}
	user, pw, err := models.GetUserByEmail(req.Email)
	if err != nil || !models.CheckPassword(req.Password, pw) {
		writeError(w, http.StatusUnauthorized, "invalid credentials")
		return
	}
	token, _ := middleware.GenerateToken(user.ID, user.Role)
	writeJSON(w, http.StatusOK, map[string]interface{}{"token": token, "user": user})
}
