# Design Document: Reservation Queue & Concurrent Checkout Handling

## Capstone Project 10 — Library Book Management System

---

## System Overview

A library has **book titles** with multiple **physical copies**. The core challenges are:
1. **Concurrent checkout** — 30 students trying to grab the last copy simultaneously
2. **Reservation queue** — FIFO waiting list when all copies are out
3. **Automatic fulfilment** — first in queue gets the copy when someone returns it
4. **Fine calculation** — ₹5 per day penalty for late returns

---

## Challenge 1: Concurrent Checkout (Race Condition)

### The Problem (TOCTOU Race)
```
Student A: SELECT available = 1  ← both see copy available
Student B: SELECT available = 1  ← race!
Student A: INSERT checkout        ← succeeds
Student B: INSERT checkout        ← also succeeds → TWO CHECKOUTS for ONE COPY!
```

### Our Solution: `BEGIN IMMEDIATE` Transaction + Single Connection

In `models/checkout.go → CheckoutBook()`:

```go
tx, _ := db.DB.Begin()

// All inside one transaction — serialised by SQLite's write lock
tx.QueryRow(`SELECT available_spots FROM book_copies WHERE id=? AND status='available' LIMIT 1`).Scan(&copy)

if copy == nil {
    tx.Rollback()
    return ErrNoCopyAvailable  // → HTTP 409, tell student to reserve
}

tx.Exec(`UPDATE book_copies SET status='checked_out' WHERE id=?`, copy.ID)
tx.Exec(`INSERT INTO checkouts (copy_id, user_id, due_date) VALUES (...)`)
tx.Commit()  // atomic — either all succeed or none
```

`DB.SetMaxOpenConns(1)` means SQLite serializes all writes. Only **one goroutine writes at a time** — no two goroutines can ever both see the same copy as available.

---

## Challenge 2: Reservation Queue

### Design: FIFO Queue Table

```sql
reservations (
    book_id, user_id, status='waiting',
    reserved_at DATETIME  ← ordered by this for FIFO
)
```

When a student tries to checkout but all copies are taken → HTTP 409 → they call `POST /api/books/:id/reserve` → they're added to `reservations` with `status='waiting'`.

**Queue position** is computed as:
```sql
SELECT COUNT(*) FROM reservations
WHERE book_id=? AND status='waiting' AND id <= ?
```

### Preventing Duplicate Reservations

The `UNIQUE(book_id, user_id, status)` constraint ensures a student can only have **one active reservation** per book.

---

## Challenge 3: Automatic Fulfilment on Return

The return flow in `models/checkout.go → ReturnBook()` does everything in **one atomic transaction**:

```
Step 1: Mark checkout as returned, compute fine
Step 2: Query reservations WHERE book_id=? AND status='waiting' ORDER BY reserved_at ASC LIMIT 1
Step 3a: If someone is waiting →
         - mark their reservation as 'fulfilled'
         - create a NEW checkout for them immediately (copy stays 'checked_out')
Step 3b: If nobody waiting →
         - mark copy status back to 'available'
Step 4: COMMIT (all-or-nothing)
```

This means the queue is always served in FIFO order, and the book never even briefly becomes "available" if someone is waiting for it.

---

## Fine Calculation

Fine is calculated at return time:

```go
func calculateFine(due, returned time.Time) float64 {
    if returned.Before(due) { return 0 }
    daysLate := math.Ceil(returned.Sub(due).Hours() / 24)
    return daysLate * 5.0  // ₹5 per day
}
```

- Loan period: **14 days**
- Fine rate: **₹5 per day** (charged per started day, not per hour)
- Fines are stored in the `checkouts` table and must be paid via `POST /api/checkouts/:id/pay-fine`

| Days Late | Fine |
|-----------|------|
| 0 | ₹0 |
| 1 | ₹5 |
| 5 | ₹25 |
| 14 | ₹70 |

---

## Why SQLite + Single Connection?

SQLite's concurrency model:
- Only **one writer** at a time (database-level write lock)
- Multiple concurrent **readers** allowed (WAL mode)
- `DB.SetMaxOpenConns(1)` ensures our Go app never causes "database is locked" panics

This is sufficient for library-scale traffic. For a university-wide system with thousands of concurrent users, PostgreSQL with row-level locking (`SELECT ... FOR UPDATE`) would be the upgrade path.

---

## Alternative Approaches Considered

| Approach | Verdict |
|----------|---------|
| Application mutex (`sync.Mutex`) | Only works single-process; breaks with multiple servers |
| Optimistic locking (`UPDATE WHERE copies > 0; check RowsAffected`) | Viable but needs retry logic and separate reservation handling |
| Redis queue | Requires extra infrastructure, over-engineering for this scale |
| **`BEGIN IMMEDIATE` transactions (chosen)** | Atomic, simple, correct, no extra dependencies |

---

## Test Coverage

| Test | What it Verifies |
|------|-----------------|
| `TestConcurrentCheckout` | 30 goroutines race for 3 copies → exactly 3 succeed, 27 get 409 |
| `TestFineCalculation` | On-time return → fine=0 |
| `TestReservationQueue` | FIFO ordering: student1 gets position 1, student2 gets position 2 |

Run with race detector:
```bash
go test -v -race ./...
```

---

*Prepared by: Anagal | Infosys Capstone Project 10 | February 2026*
