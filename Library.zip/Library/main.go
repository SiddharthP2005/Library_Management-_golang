package main

import (
	"fmt"
	"log"
	"net/http"
	"strings"

	"library-management/db"
	"library-management/handlers"
	"library-management/middleware"
)

func main() {
	db.Init("library.db")

	mux := http.NewServeMux()

	// ── Auth (public) ─────────────────────────────────────────────────
	mux.HandleFunc("/api/register", handlers.Register)
	mux.HandleFunc("/api/login", handlers.Login)

	// ── Books (GET public, POST/DELETE librarian) ──────────────────────
	mux.HandleFunc("/api/books", handlers.Books)
	mux.HandleFunc("/api/books/", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path

		// POST /api/books/:id/checkout
		if strings.HasSuffix(path, "/checkout") {
			middleware.Authenticate(handlers.Checkout)(w, r)
			return
		}
		// POST /api/books/:id/reserve
		if strings.HasSuffix(path, "/reserve") {
			middleware.Authenticate(handlers.Reserve)(w, r)
			return
		}
		// GET /api/books/:id/queue  (librarian)
		if strings.HasSuffix(path, "/queue") {
			middleware.Authenticate(handlers.BookQueue)(w, r)
			return
		}
		// GET/DELETE /api/books/:id
		handlers.BookByID(w, r)
	})

	// ── Checkouts ─────────────────────────────────────────────────────
	// GET  /api/checkouts        → all active checkouts (librarian)
	// GET  /api/checkouts/me     → my checkouts (student)
	mux.HandleFunc("/api/checkouts", middleware.Authenticate(handlers.AllCheckouts))
	mux.HandleFunc("/api/checkouts/", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		// GET /api/checkouts/me
		if strings.HasSuffix(path, "/me") {
			middleware.Authenticate(handlers.MyCheckouts)(w, r)
			return
		}
		// POST /api/checkouts/:id/return
		if strings.HasSuffix(path, "/return") {
			middleware.Authenticate(handlers.Return)(w, r)
			return
		}
		// POST /api/checkouts/:id/pay-fine
		if strings.HasSuffix(path, "/pay-fine") {
			middleware.Authenticate(handlers.PayFine)(w, r)
			return
		}
		http.NotFound(w, r)
	})

	// ── Reservations ─────────────────────────────────────────────────
	mux.HandleFunc("/api/reservations/me", middleware.Authenticate(handlers.MyReservations))
	mux.HandleFunc("/api/reservations/", func(w http.ResponseWriter, r *http.Request) {
		middleware.Authenticate(handlers.CancelReservation)(w, r)
	})

	// ── Fines ─────────────────────────────────────────────────────────
	mux.HandleFunc("/api/fines/me", middleware.Authenticate(handlers.MyFines))

	// ── Health ────────────────────────────────────────────────────────
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, `{"status":"ok","service":"library-management"}`)
	})

	// ── Root info ─────────────────────────────────────────────────────
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintln(w, `{
  "service": "Library Book Management System",
  "version": "1.0.0",
  "endpoints": {
    "POST /api/register":                     "Register (role: librarian|student)",
    "POST /api/login":                        "Login → token",
    "GET  /api/books":                        "Browse all books",
    "POST /api/books":                        "Add book + copies (librarian)",
    "GET  /api/books/:id":                    "Book details + availability",
    "DELETE /api/books/:id":                  "Remove book (librarian)",
    "POST /api/books/:id/checkout":           "Checkout book",
    "POST /api/books/:id/reserve":            "Join reservation queue",
    "GET  /api/books/:id/queue":              "View reservation queue (librarian)",
    "GET  /api/checkouts":                    "All active checkouts (librarian)",
    "GET  /api/checkouts/me":                 "My checkouts",
    "POST /api/checkouts/:id/return":         "Return book (auto-calculates fine)",
    "POST /api/checkouts/:id/pay-fine":       "Pay late fine",
    "GET  /api/reservations/me":              "My reservations",
    "DELETE /api/reservations/:id":           "Cancel reservation",
    "GET  /api/fines/me":                     "My fines summary"
  }
}`)
	})

	port := "8080"
	log.Printf("📚  Library Management API running on http://localhost:%s", port)
	log.Fatal(http.ListenAndServe(":"+port, mux))
}
