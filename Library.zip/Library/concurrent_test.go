package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"

	"library-management/db"
	"library-management/handlers"
	"library-management/middleware"
)

func setupTestServer(t *testing.T) *httptest.Server {
	t.Helper()
	db.Init(t.TempDir() + "/test.db")

	mux := http.NewServeMux()
	mux.HandleFunc("/api/register", handlers.Register)
	mux.HandleFunc("/api/login", handlers.Login)
	mux.HandleFunc("/api/books", handlers.Books)
	mux.HandleFunc("/api/books/", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		if strings.HasSuffix(path, "/checkout") {
			middleware.Authenticate(handlers.Checkout)(w, r)
			return
		}
		if strings.HasSuffix(path, "/reserve") {
			middleware.Authenticate(handlers.Reserve)(w, r)
			return
		}
		if strings.HasSuffix(path, "/queue") {
			middleware.Authenticate(handlers.BookQueue)(w, r)
			return
		}
		handlers.BookByID(w, r)
	})
	mux.HandleFunc("/api/checkouts", middleware.Authenticate(handlers.AllCheckouts))
	mux.HandleFunc("/api/checkouts/", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Path
		if strings.HasSuffix(path, "/me") {
			middleware.Authenticate(handlers.MyCheckouts)(w, r)
			return
		}
		if strings.HasSuffix(path, "/return") {
			middleware.Authenticate(handlers.Return)(w, r)
			return
		}
		if strings.HasSuffix(path, "/pay-fine") {
			middleware.Authenticate(handlers.PayFine)(w, r)
			return
		}
		http.NotFound(w, r)
	})
	mux.HandleFunc("/api/reservations/me", middleware.Authenticate(handlers.MyReservations))
	mux.HandleFunc("/api/reservations/", func(w http.ResponseWriter, r *http.Request) {
		middleware.Authenticate(handlers.CancelReservation)(w, r)
	})
	mux.HandleFunc("/api/fines/me", middleware.Authenticate(handlers.MyFines))
	return httptest.NewServer(mux)
}

func createLibrarianAndBook(t *testing.T, baseURL string, copies int) (string, int64) {
	t.Helper()
	body, _ := json.Marshal(map[string]string{
		"name": "Librarian", "email": "lib@test.com",
		"password": "secret", "role": "librarian",
	})
	resp, _ := http.Post(baseURL+"/api/register", "application/json", bytes.NewReader(body))
	var ar map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&ar)
	resp.Body.Close()
	token := ar["token"].(string)

	bookBody, _ := json.Marshal(map[string]interface{}{
		"title": "Clean Code", "author": "Robert Martin",
		"isbn": "9780132350884", "genre": "Programming",
		"copies": copies,
	})
	req, _ := http.NewRequest(http.MethodPost, baseURL+"/api/books", bytes.NewReader(bookBody))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	resp2, _ := http.DefaultClient.Do(req)
	var br map[string]interface{}
	json.NewDecoder(resp2.Body).Decode(&br)
	resp2.Body.Close()
	return token, int64(br["id"].(float64))
}

func registerStudent(t *testing.T, baseURL string, idx int) string {
	t.Helper()
	body, _ := json.Marshal(map[string]string{
		"name":     fmt.Sprintf("Student%d", idx),
		"email":    fmt.Sprintf("student%d@test.com", idx),
		"password": "pass", "role": "student",
	})
	resp, _ := http.Post(baseURL+"/api/register", "application/json", bytes.NewReader(body))
	var ar map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&ar)
	resp.Body.Close()
	return ar["token"].(string)
}

// ─────────────────────────────────────────────────────────────────────────────
// TestConcurrentCheckout: 30 students race to checkout a book with only 3 copies.
// Expected: exactly 3 succeed (HTTP 201), 27 get HTTP 409.
// ─────────────────────────────────────────────────────────────────────────────
func TestConcurrentCheckout(t *testing.T) {
	const (
		totalStudents = 30
		copies        = 3
	)
	server := setupTestServer(t)
	defer server.Close()
	baseURL := server.URL

	tokens := make([]string, totalStudents)
	for i := 0; i < totalStudents; i++ {
		tokens[i] = registerStudent(t, baseURL, i)
	}
	_, bookID := createLibrarianAndBook(t, baseURL, copies)

	var (
		successCount int32
		conflictCount int32
		errorCount   int32
		wg           sync.WaitGroup
		startGun     = make(chan struct{})
	)

	for i := 0; i < totalStudents; i++ {
		wg.Add(1)
		go func(token string) {
			defer wg.Done()
			<-startGun

			url := fmt.Sprintf("%s/api/books/%d/checkout", baseURL, bookID)
			req, _ := http.NewRequest(http.MethodPost, url, nil)
			req.Header.Set("Authorization", "Bearer "+token)
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				atomic.AddInt32(&errorCount, 1)
				return
			}
			io.Copy(io.Discard, resp.Body)
			resp.Body.Close()

			switch resp.StatusCode {
			case http.StatusCreated:
				atomic.AddInt32(&successCount, 1)
			case http.StatusConflict:
				atomic.AddInt32(&conflictCount, 1)
			default:
				atomic.AddInt32(&errorCount, 1)
			}
		}(tokens[i])
	}

	close(startGun)
	wg.Wait()

	t.Logf("Results → success=%d conflict=%d error=%d", successCount, conflictCount, errorCount)

	if int(successCount) != copies {
		t.Errorf("expected exactly %d checkouts, got %d (OVERBOOKING DETECTED!)", copies, successCount)
	}
	if int(conflictCount) != totalStudents-copies {
		t.Errorf("expected %d conflicts, got %d", totalStudents-copies, conflictCount)
	}
	if errorCount != 0 {
		t.Errorf("unexpected errors: %d", errorCount)
	}
	t.Log("✅ No overbooking — concurrent checkout handled correctly")
}

// TestFineCalculation: checks that fine is 0 when returned on time and > 0 when late.
func TestFineCalculation(t *testing.T) {
	server := setupTestServer(t)
	defer server.Close()

	_, bookID := createLibrarianAndBook(t, server.URL, 1)
	studentToken := registerStudent(t, server.URL, 100)

	// Checkout
	url := fmt.Sprintf("%s/api/books/%d/checkout", server.URL, bookID)
	req, _ := http.NewRequest(http.MethodPost, url, nil)
	req.Header.Set("Authorization", "Bearer "+studentToken)
	resp, _ := http.DefaultClient.Do(req)
	var cr map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&cr)
	resp.Body.Close()

	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("checkout failed: %d", resp.StatusCode)
	}
	checkoutID := int64(cr["checkout_id"].(float64))
	t.Logf("✅ Checkout successful, due_date=%v", cr["due_date"])

	// Return immediately (no fine expected)
	retURL := fmt.Sprintf("%s/api/checkouts/%d/return", server.URL, checkoutID)
	req2, _ := http.NewRequest(http.MethodPost, retURL, nil)
	req2.Header.Set("Authorization", "Bearer "+studentToken)
	resp2, _ := http.DefaultClient.Do(req2)
	var rr map[string]interface{}
	json.NewDecoder(resp2.Body).Decode(&rr)
	resp2.Body.Close()

	if resp2.StatusCode != http.StatusOK {
		t.Fatalf("return failed: %d", resp2.StatusCode)
	}
	fine := rr["fine_amount"].(float64)
	if fine != 0 {
		t.Errorf("expected 0 fine for on-time return, got %.2f", fine)
	}
	t.Logf("✅ Fine = ₹%.2f (correct — returned on time)", fine)
}

// TestReservationQueue: verifies FIFO reservation ordering.
func TestReservationQueue(t *testing.T) {
	server := setupTestServer(t)
	defer server.Close()

	// Book with 0 available (1 copy, pre-checked-out by student0)
	_, bookID := createLibrarianAndBook(t, server.URL, 1)
	tok0 := registerStudent(t, server.URL, 200)

	// Student 0 checks out the only copy
	coURL := fmt.Sprintf("%s/api/books/%d/checkout", server.URL, bookID)
	req, _ := http.NewRequest(http.MethodPost, coURL, nil)
	req.Header.Set("Authorization", "Bearer "+tok0)
	resp, _ := http.DefaultClient.Do(req)
	resp.Body.Close()
	if resp.StatusCode != http.StatusCreated {
		t.Fatalf("initial checkout failed: %d", resp.StatusCode)
	}

	// Students 1 and 2 try to reserve — should get queue positions 1 and 2
	tok1 := registerStudent(t, server.URL, 201)
	tok2 := registerStudent(t, server.URL, 202)

	reserve := func(token string) (int, float64) {
		resURL := fmt.Sprintf("%s/api/books/%d/reserve", server.URL, bookID)
		req, _ := http.NewRequest(http.MethodPost, resURL, nil)
		req.Header.Set("Authorization", "Bearer "+token)
		resp, _ := http.DefaultClient.Do(req)
		var rr map[string]interface{}
		json.NewDecoder(resp.Body).Decode(&rr)
		resp.Body.Close()
		pos := 0.0
		if v, ok := rr["queue_position"]; ok {
			pos = v.(float64)
		}
		return resp.StatusCode, pos
	}

	s1, pos1 := reserve(tok1)
	s2, pos2 := reserve(tok2)

	if s1 != http.StatusCreated || s2 != http.StatusCreated {
		t.Fatalf("reservations failed: %d %d", s1, s2)
	}
	if pos1 != 1 {
		t.Errorf("expected student1 at queue position 1, got %.0f", pos1)
	}
	if pos2 != 2 {
		t.Errorf("expected student2 at queue position 2, got %.0f", pos2)
	}
	t.Logf("✅ FIFO queue correct: student1=pos%.0f, student2=pos%.0f", pos1, pos2)
}
