# 📚 Library Book Management System API

A complete REST API for a library management system built in Go — similar to a college library portal. Librarians manage books and inventory, students check out and return books, and the system handles reservations and calculates fines for late returns.

---

## 🚀 Quick Start

### Prerequisites
- Go 1.21+

### Run the Server
```bash
go mod tidy
go run ./...
```

Server starts at **http://localhost:8080**

### Run Tests
```bash
go test -v -race ./...
```

---

## 📁 Project Structure

```
Library/
├── main.go                    # Server entry point
├── go.mod / go.sum            # Dependencies
├── schema.sql                 # DB schema reference
├── db/db.go                   # SQLite + WAL + migrations
├── models/
│   ├── user.go                # Users (librarian / student)
│   ├── book.go                # Books + physical copies
│   ├── checkout.go            # Checkout, return, fine calc
│   └── reservation.go         # FIFO reservation queue
├── handlers/
│   ├── auth.go                # Register, Login
│   ├── books.go               # Book CRUD
│   ├── checkouts.go           # Checkout, return, pay fine, fines
│   ├── reservations.go        # Reserve, cancel, view queue
│   └── helpers.go             # JSON utilities
├── middleware/auth.go          # HMAC-SHA256 token auth
├── concurrent_test.go          # Concurrent checkout + queue tests
├── DESIGN.md                  # Architecture & concurrency design
└── prompts.md                 # AI prompts used
```

---

## 🔌 API Endpoints

### Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| `POST` | `/api/register` | None | Register (role: `librarian` or `student`) |
| `POST` | `/api/login` | None | Login → receive token |

### Books

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| `GET` | `/api/books` | None | Browse all books with availability |
| `POST` | `/api/books` | Librarian | Add book + N copies |
| `GET` | `/api/books/:id` | None | Book details |
| `DELETE` | `/api/books/:id` | Librarian | Remove book |
| `POST` | `/api/books/:id/checkout` | Any | Checkout book (concurrent-safe) |
| `POST` | `/api/books/:id/reserve` | Any | Join reservation queue |
| `GET` | `/api/books/:id/queue` | Librarian | View waiting queue |

### Checkouts

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| `GET` | `/api/checkouts` | Librarian | All active checkouts |
| `GET` | `/api/checkouts/me` | Any | My checkout history |
| `POST` | `/api/checkouts/:id/return` | Any | Return book (auto-calculates fine) |
| `POST` | `/api/checkouts/:id/pay-fine` | Any | Pay late fine |

### Reservations & Fines

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| `GET` | `/api/reservations/me` | Any | My reservations |
| `DELETE` | `/api/reservations/:id` | Any | Cancel reservation |
| `GET` | `/api/fines/me` | Any | My fines summary |

---

## 📋 Example curl Commands

### Register a Librarian
```bash
curl -X POST http://localhost:8080/api/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Alice","email":"alice@lib.com","password":"pass","role":"librarian"}'
```

### Add a Book (3 copies)
```bash
curl -X POST http://localhost:8080/api/books \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"title":"Clean Code","author":"Robert Martin","isbn":"9780132350884","genre":"Programming","copies":3}'
```

### Register a Student and Checkout
```bash
# Register student
curl -X POST http://localhost:8080/api/register \
  -d '{"name":"Bob","email":"bob@student.com","password":"pass","role":"student"}'

# Checkout book
curl -X POST http://localhost:8080/api/books/1/checkout \
  -H "Authorization: Bearer <student_token>"
```
**Response:**
```json
{
  "message": "book checked out successfully",
  "checkout_id": 1,
  "copy_no": "COPY-001",
  "due_date": "2026-03-07T09:00:00Z",
  "loan_days": 14,
  "fine_per_day": 5
}
```

### Return a Book
```bash
curl -X POST http://localhost:8080/api/checkouts/1/return \
  -H "Authorization: Bearer <token>"
```
**Response (with fine):**
```json
{
  "message": "book returned successfully",
  "fine_amount": 25,
  "fine_message": "you have an outstanding fine — pay via POST /api/checkouts/1/pay-fine"
}
```

### Reserve a Book (when fully checked out)
```bash
curl -X POST http://localhost:8080/api/books/1/reserve \
  -H "Authorization: Bearer <token>"
```
**Response:**
```json
{
  "message": "reservation created",
  "reservation_id": 3,
  "queue_position": 2,
  "status": "waiting"
}
```

---

## 🗄 Database Schema

**SQLite** — single-file DB, zero config. Created automatically on first run as `library.db`.

```sql
-- Separate tables for titles and physical copies
books        → catalogue of book titles (isbn unique)
book_copies  → physical copies (status: available|checked_out|reserved|lost)
users        → librarians + students (bcrypt hashed passwords)
checkouts    → loan records with due_date, returned_at, fine_amount
reservations → FIFO queue per book (status: waiting|fulfilled|cancelled)
```

---

## ⚡ Concurrency & Reservation Strategy

See [DESIGN.md](./DESIGN.md) for the full deep-dive.

**Concurrent Checkout:** Uses `BEGIN IMMEDIATE` SQLite transactions so only one goroutine can read-check-update `available_copies` at a time. `DB.SetMaxOpenConns(1)` serializes writers.

**Reservation Queue:** FIFO ordered by `reserved_at`. On book return, if anyone is waiting, the system automatically creates a new checkout for the next person in queue within the same transaction.

**Fine calculation:** ₹5 per day late. Computed on return as `ceil(days_late) × 5`.

---

## 🧑‍💻 Roles

| Role | Permissions |
|------|-------------|
| `librarian` | Add/delete books; view all checkouts & reservation queues |
| `student` | Browse, checkout, reserve, return, pay fines |

---

*Built for Infosys Capstone Project 10 — Go (Golang)*
