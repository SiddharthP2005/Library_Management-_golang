-- Library Book Management System -- Database Schema

-- Users: librarians manage inventory; students borrow books
CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    email      TEXT    NOT NULL UNIQUE,
    password   TEXT    NOT NULL,
    role       TEXT    NOT NULL CHECK(role IN ('librarian','student')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Books: catalogue entry (one row per title)
CREATE TABLE IF NOT EXISTS books (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT    NOT NULL,
    author      TEXT    NOT NULL,
    isbn        TEXT    NOT NULL UNIQUE,
    genre       TEXT    NOT NULL DEFAULT 'General',
    description TEXT    NOT NULL DEFAULT '',
    added_by    INTEGER NOT NULL REFERENCES users(id),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Book copies: physical copies of a title
CREATE TABLE IF NOT EXISTS book_copies (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id    INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    copy_no    TEXT    NOT NULL,            -- e.g. "COPY-001"
    status     TEXT    NOT NULL DEFAULT 'available'
               CHECK(status IN ('available','checked_out','reserved','lost')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(book_id, copy_no)
);

-- Checkouts: tracks who has which copy and when
CREATE TABLE IF NOT EXISTS checkouts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    copy_id      INTEGER  NOT NULL REFERENCES book_copies(id),
    user_id      INTEGER  NOT NULL REFERENCES users(id),
    checked_out_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    due_date     DATETIME NOT NULL,         -- 14 days from checkout
    returned_at  DATETIME,                  -- NULL means currently checked out
    fine_amount  REAL     NOT NULL DEFAULT 0.0,
    fine_paid    INTEGER  NOT NULL DEFAULT 0 CHECK(fine_paid IN (0,1))
);

-- Reservations: queue for unavailable books
CREATE TABLE IF NOT EXISTS reservations (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id      INTEGER  NOT NULL REFERENCES books(id) ON DELETE CASCADE,
    user_id      INTEGER  NOT NULL REFERENCES users(id),
    status       TEXT     NOT NULL DEFAULT 'waiting'
                 CHECK(status IN ('waiting','fulfilled','cancelled','expired')),
    reserved_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    fulfilled_at DATETIME,
    UNIQUE(book_id, user_id, status)  -- one active reservation per user per book
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_copies_book      ON book_copies(book_id);
CREATE INDEX IF NOT EXISTS idx_copies_status    ON book_copies(status);
CREATE INDEX IF NOT EXISTS idx_checkouts_user   ON checkouts(user_id);
CREATE INDEX IF NOT EXISTS idx_checkouts_copy   ON checkouts(copy_id);
CREATE INDEX IF NOT EXISTS idx_reservations_book ON reservations(book_id, status);
CREATE INDEX IF NOT EXISTS idx_reservations_user ON reservations(user_id);
