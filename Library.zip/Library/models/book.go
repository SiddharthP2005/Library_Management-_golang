package models

import (
	"database/sql"
	"errors"
	"fmt"
	"time"

	"library-management/db"
)

type Book struct {
	ID          int64     `json:"id"`
	Title       string    `json:"title"`
	Author      string    `json:"author"`
	ISBN        string    `json:"isbn"`
	Genre       string    `json:"genre"`
	Description string    `json:"description"`
	AddedBy     int64     `json:"added_by"`
	TotalCopies int       `json:"total_copies"`
	Available   int       `json:"available_copies"`
	CreatedAt   time.Time `json:"created_at"`
}

type BookCopy struct {
	ID        int64     `json:"id"`
	BookID    int64     `json:"book_id"`
	CopyNo    string    `json:"copy_no"`
	Status    string    `json:"status"` // available | checked_out | reserved | lost
	CreatedAt time.Time `json:"created_at"`
}

func CreateBook(title, author, isbn, genre, desc string, addedBy int64, copies int) (*Book, error) {
	tx, err := db.DB.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback() //nolint:errcheck

	res, err := tx.Exec(
		`INSERT INTO books (title, author, isbn, genre, description, added_by) VALUES (?, ?, ?, ?, ?, ?)`,
		title, author, isbn, genre, desc, addedBy,
	)
	if err != nil {
		return nil, err
	}
	bookID, _ := res.LastInsertId()

	for i := 1; i <= copies; i++ {
		copyNo := fmt.Sprintf("COPY-%03d", i)
		if _, err = tx.Exec(
			`INSERT INTO book_copies (book_id, copy_no) VALUES (?, ?)`, bookID, copyNo,
		); err != nil {
			return nil, err
		}
	}
	if err = tx.Commit(); err != nil {
		return nil, err
	}
	return &Book{
		ID: bookID, Title: title, Author: author, ISBN: isbn,
		Genre: genre, Description: desc, AddedBy: addedBy,
		TotalCopies: copies, Available: copies, CreatedAt: time.Now(),
	}, nil
}

func ListBooks() ([]Book, error) {
	rows, err := db.DB.Query(`
		SELECT b.id, b.title, b.author, b.isbn, b.genre, b.description, b.added_by, b.created_at,
		       COUNT(c.id) AS total,
		       SUM(CASE WHEN c.status='available' THEN 1 ELSE 0 END) AS avail
		FROM books b
		LEFT JOIN book_copies c ON c.book_id = b.id
		GROUP BY b.id ORDER BY b.title ASC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var books []Book
	for rows.Next() {
		var bk Book
		if err := rows.Scan(&bk.ID, &bk.Title, &bk.Author, &bk.ISBN, &bk.Genre,
			&bk.Description, &bk.AddedBy, &bk.CreatedAt, &bk.TotalCopies, &bk.Available); err != nil {
			return nil, err
		}
		books = append(books, bk)
	}
	return books, rows.Err()
}

func GetBookByID(id int64) (*Book, error) {
	row := db.DB.QueryRow(`
		SELECT b.id, b.title, b.author, b.isbn, b.genre, b.description, b.added_by, b.created_at,
		       COUNT(c.id),
		       SUM(CASE WHEN c.status='available' THEN 1 ELSE 0 END)
		FROM books b
		LEFT JOIN book_copies c ON c.book_id = b.id
		WHERE b.id = ? GROUP BY b.id`, id)
	bk := &Book{}
	err := row.Scan(&bk.ID, &bk.Title, &bk.Author, &bk.ISBN, &bk.Genre,
		&bk.Description, &bk.AddedBy, &bk.CreatedAt, &bk.TotalCopies, &bk.Available)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, errors.New("book not found")
	}
	return bk, err
}

func DeleteBook(id int64) error {
	_, err := db.DB.Exec(`DELETE FROM books WHERE id = ?`, id)
	return err
}

// GetAvailableCopy returns the first available copy of a book (within a transaction).
func GetAvailableCopyTx(tx *sql.Tx, bookID int64) (*BookCopy, error) {
	row := tx.QueryRow(
		`SELECT id, book_id, copy_no, status, created_at FROM book_copies
		 WHERE book_id = ? AND status = 'available' LIMIT 1`, bookID,
	)
	c := &BookCopy{}
	err := row.Scan(&c.ID, &c.BookID, &c.CopyNo, &c.Status, &c.CreatedAt)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil // no copy available
	}
	return c, err
}
