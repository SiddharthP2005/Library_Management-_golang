package models

import (
	"errors"
	"time"

	"library-management/db"
)

type Reservation struct {
	ID          int64      `json:"id"`
	BookID      int64      `json:"book_id"`
	BookTitle   string     `json:"book_title,omitempty"`
	UserID      int64      `json:"user_id"`
	Status      string     `json:"status"` // waiting|fulfilled|cancelled|expired
	ReservedAt  time.Time  `json:"reserved_at"`
	FulfilledAt *time.Time `json:"fulfilled_at"`
	QueuePos    int        `json:"queue_position,omitempty"`
}

var ErrAlreadyReserved = errors.New("you already have an active reservation for this book")

// CreateReservation adds a student to the waiting queue for a book.
// Returns queue position (1 = next in line).
func CreateReservation(bookID, userID int64) (*Reservation, error) {
	tx, err := db.DB.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback() //nolint:errcheck

	// Check existing active reservation
	var existing int
	tx.QueryRow(`
		SELECT COUNT(*) FROM reservations
		WHERE book_id=? AND user_id=? AND status='waiting'`, bookID, userID).Scan(&existing)
	if existing > 0 {
		return nil, ErrAlreadyReserved
	}

	res, err := tx.Exec(
		`INSERT INTO reservations (book_id, user_id) VALUES (?, ?)`, bookID, userID,
	)
	if err != nil {
		if isUniqueErr(err) {
			return nil, ErrAlreadyReserved
		}
		return nil, err
	}
	id, _ := res.LastInsertId()

	// Calculate queue position
	var pos int
	tx.QueryRow(`
		SELECT COUNT(*) FROM reservations
		WHERE book_id=? AND status='waiting' AND id<=?`, bookID, id).Scan(&pos)

	if err = tx.Commit(); err != nil {
		return nil, err
	}
	return &Reservation{
		ID: id, BookID: bookID, UserID: userID,
		Status: "waiting", ReservedAt: time.Now(), QueuePos: pos,
	}, nil
}

// CancelReservation allows a student to cancel their own reservation.
func CancelReservation(reservationID, userID int64) error {
	res, err := db.DB.Exec(
		`UPDATE reservations SET status='cancelled' WHERE id=? AND user_id=? AND status='waiting'`,
		reservationID, userID,
	)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return errors.New("reservation not found or not cancellable")
	}
	return nil
}

// ListUserReservations returns all reservations for a user.
func ListUserReservations(userID int64) ([]Reservation, error) {
	rows, err := db.DB.Query(`
		SELECT r.id, r.book_id, b.title, r.user_id, r.status, r.reserved_at, r.fulfilled_at
		FROM reservations r
		JOIN books b ON b.id = r.book_id
		WHERE r.user_id = ?
		ORDER BY r.reserved_at DESC`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanReservations(rows)
}

// ListBookReservations returns the waiting queue for a book (librarian view).
func ListBookReservations(bookID int64) ([]Reservation, error) {
	rows, err := db.DB.Query(`
		SELECT r.id, r.book_id, b.title, r.user_id, r.status, r.reserved_at, r.fulfilled_at
		FROM reservations r
		JOIN books b ON b.id = r.book_id
		WHERE r.book_id = ? AND r.status = 'waiting'
		ORDER BY r.reserved_at ASC`, bookID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanReservations(rows)
}

func scanReservations(rows interface{ Next() bool; Scan(...interface{}) error; Err() error }) ([]Reservation, error) {
	var list []Reservation
	for rows.Next() {
		r := Reservation{}
		if err := rows.Scan(&r.ID, &r.BookID, &r.BookTitle, &r.UserID,
			&r.Status, &r.ReservedAt, &r.FulfilledAt); err != nil {
			return nil, err
		}
		list = append(list, r)
	}
	return list, rows.Err()
}

func isUniqueErr(err error) bool {
	if err == nil {
		return false
	}
	msg := err.Error()
	for i := 0; i <= len(msg)-len("UNIQUE"); i++ {
		if msg[i:i+6] == "UNIQUE" {
			return true
		}
	}
	return false
}
