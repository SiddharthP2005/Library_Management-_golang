package models

import (
	"errors"
	"fmt"
	"math"
	"time"

	"library-management/db"
)

const (
	CheckoutDays    = 14   // standard loan period in days
	FinePerDay      = 5.0  // ₹5 per day late fine
)

type Checkout struct {
	ID            int64      `json:"id"`
	CopyID        int64      `json:"copy_id"`
	UserID        int64      `json:"user_id"`
	CopyNo        string     `json:"copy_no,omitempty"`
	BookTitle     string     `json:"book_title,omitempty"`
	CheckedOutAt  time.Time  `json:"checked_out_at"`
	DueDate       time.Time  `json:"due_date"`
	ReturnedAt    *time.Time `json:"returned_at"`
	FineAmount    float64    `json:"fine_amount"`
	FinePaid      bool       `json:"fine_paid"`
}

// ErrNoCopyAvailable is returned when all copies of a book are checked out.
var ErrNoCopyAvailable = errors.New("no copy available — please reserve the book")

// ErrAlreadyCheckedOut is returned when the user already has this book.
var ErrAlreadyCheckedOut = errors.New("you already have a copy of this book checked out")

// CheckoutBook atomically:
//  1. Locks the DB (BEGIN IMMEDIATE via single connection)
//  2. Finds an available copy
//  3. Marks copy as 'checked_out'
//  4. Creates a checkout record with due_date = now + 14 days
//
// If no copy is available → ErrNoCopyAvailable (caller should create reservation).
// Concurrent requests are serialised by SetMaxOpenConns(1).
func CheckoutBook(bookID, userID int64) (*Checkout, error) {
	tx, err := db.DB.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback() //nolint:errcheck

	// Check if user already has this book
	var existing int
	tx.QueryRow(`
		SELECT COUNT(*) FROM checkouts co
		JOIN book_copies bc ON bc.id = co.copy_id
		WHERE bc.book_id = ? AND co.user_id = ? AND co.returned_at IS NULL`,
		bookID, userID).Scan(&existing)
	if existing > 0 {
		return nil, ErrAlreadyCheckedOut
	}

	// Find available copy
	copy, err := GetAvailableCopyTx(tx, bookID)
	if err != nil {
		return nil, err
	}
	if copy == nil {
		return nil, ErrNoCopyAvailable
	}

	// Mark copy as checked_out
	if _, err = tx.Exec(`UPDATE book_copies SET status='checked_out' WHERE id=?`, copy.ID); err != nil {
		return nil, err
	}

	// Create checkout record
	dueDate := time.Now().Add(CheckoutDays * 24 * time.Hour)
	res, err := tx.Exec(
		`INSERT INTO checkouts (copy_id, user_id, due_date) VALUES (?, ?, ?)`,
		copy.ID, userID, dueDate,
	)
	if err != nil {
		return nil, err
	}
	if err = tx.Commit(); err != nil {
		return nil, err
	}

	id, _ := res.LastInsertId()
	return &Checkout{
		ID: id, CopyID: copy.ID, UserID: userID,
		CopyNo: copy.CopyNo, CheckedOutAt: time.Now(), DueDate: dueDate,
	}, nil
}

// ReturnBook marks a copy as returned, calculates fines, and fulfils the
// next waiting reservation (if any) atomically.
func ReturnBook(checkoutID, userID int64) (*Checkout, error) {
	tx, err := db.DB.Begin()
	if err != nil {
		return nil, err
	}
	defer tx.Rollback() //nolint:errcheck

	// Fetch checkout
	co := &Checkout{}
	err = tx.QueryRow(`
		SELECT id, copy_id, user_id, checked_out_at, due_date, returned_at, fine_amount
		FROM checkouts WHERE id = ? AND user_id = ? AND returned_at IS NULL`,
		checkoutID, userID,
	).Scan(&co.ID, &co.CopyID, &co.UserID, &co.CheckedOutAt, &co.DueDate, &co.ReturnedAt, &co.FineAmount)
	if err != nil {
		return nil, errors.New("checkout not found or already returned")
	}

	now := time.Now()
	fine := calculateFine(co.DueDate, now)

	// Mark as returned
	if _, err = tx.Exec(
		`UPDATE checkouts SET returned_at=?, fine_amount=? WHERE id=?`, now, fine, co.ID,
	); err != nil {
		return nil, err
	}

	// Check for waiting reservations for this book
	var bookID int64
	var reservationID int64
	var reservationUserID int64
	err = tx.QueryRow(`
		SELECT bc.book_id, r.id, r.user_id FROM book_copies bc
		JOIN reservations r ON r.book_id = bc.book_id
		WHERE bc.id = ? AND r.status = 'waiting'
		ORDER BY r.reserved_at ASC LIMIT 1`, co.CopyID).
		Scan(&bookID, &reservationID, &reservationUserID)

	if err == nil {
		// Fulfil the reservation — keep copy status 'checked_out' for the next user
		if _, err = tx.Exec(
			`UPDATE reservations SET status='fulfilled', fulfilled_at=? WHERE id=?`, now, reservationID,
		); err != nil {
			return nil, err
		}
		// Create new checkout for reserved user
		dueDate := now.Add(CheckoutDays * 24 * time.Hour)
		if _, err = tx.Exec(
			`INSERT INTO checkouts (copy_id, user_id, due_date) VALUES (?, ?, ?)`,
			co.CopyID, reservationUserID, dueDate,
		); err != nil {
			return nil, err
		}
		_ = bookID
	} else {
		// No reservation — mark copy available
		if _, err = tx.Exec(
			`UPDATE book_copies SET status='available' WHERE id=?`, co.CopyID,
		); err != nil {
			return nil, err
		}
	}

	if err = tx.Commit(); err != nil {
		return nil, err
	}
	co.ReturnedAt = &now
	co.FineAmount = fine
	return co, nil
}

// ListUserCheckouts returns all checkouts for a user.
func ListUserCheckouts(userID int64) ([]Checkout, error) {
	rows, err := db.DB.Query(`
		SELECT co.id, co.copy_id, co.user_id, bc.copy_no, b.title,
		       co.checked_out_at, co.due_date, co.returned_at, co.fine_amount, co.fine_paid
		FROM checkouts co
		JOIN book_copies bc ON bc.id = co.copy_id
		JOIN books b ON b.id = bc.book_id
		WHERE co.user_id = ?
		ORDER BY co.checked_out_at DESC`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanCheckouts(rows)
}

// ListAllCheckouts returns all active (unreturned) checkouts (librarian view).
func ListAllCheckouts() ([]Checkout, error) {
	rows, err := db.DB.Query(`
		SELECT co.id, co.copy_id, co.user_id, bc.copy_no, b.title,
		       co.checked_out_at, co.due_date, co.returned_at, co.fine_amount, co.fine_paid
		FROM checkouts co
		JOIN book_copies bc ON bc.id = co.copy_id
		JOIN books b ON b.id = bc.book_id
		WHERE co.returned_at IS NULL
		ORDER BY co.due_date ASC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanCheckouts(rows)
}

func scanCheckouts(rows interface{ Next() bool; Scan(...interface{}) error; Err() error }) ([]Checkout, error) {
	var list []Checkout
	for rows.Next() {
		co := Checkout{}
		var finePaidInt int
		if err := rows.Scan(&co.ID, &co.CopyID, &co.UserID, &co.CopyNo, &co.BookTitle,
			&co.CheckedOutAt, &co.DueDate, &co.ReturnedAt, &co.FineAmount, &finePaidInt); err != nil {
			return nil, err
		}
		co.FinePaid = finePaidInt == 1
		list = append(list, co)
	}
	return list, rows.Err()
}

// PayFine marks a checkout's fine as paid.
func PayFine(checkoutID, userID int64) error {
	res, err := db.DB.Exec(
		`UPDATE checkouts SET fine_paid=1 WHERE id=? AND user_id=? AND fine_amount > 0`,
		checkoutID, userID,
	)
	if err != nil {
		return err
	}
	n, _ := res.RowsAffected()
	if n == 0 {
		return errors.New("no unpaid fine found for this checkout")
	}
	return nil
}

// calculateFine computes late fine. Returns 0 if returned on time.
func calculateFine(due, returned time.Time) float64 {
	if returned.Before(due) || returned.Equal(due) {
		return 0
	}
	daysLate := math.Ceil(returned.Sub(due).Hours() / 24)
	return daysLate * FinePerDay
}

// FinesSummary holds aggregated fine info for a user.
type FinesSummary struct {
	UserID      int64   `json:"user_id"`
	TotalFines  float64 `json:"total_fines"`
	PaidFines   float64 `json:"paid_fines"`
	UnpaidFines float64 `json:"unpaid_fines"`
	Details     []FineDetail `json:"details"`
}

type FineDetail struct {
	CheckoutID int64   `json:"checkout_id"`
	BookTitle  string  `json:"book_title"`
	DueDate    time.Time `json:"due_date"`
	ReturnedAt *time.Time `json:"returned_at"`
	FineAmount float64 `json:"fine_amount"`
	FinePaid   bool    `json:"fine_paid"`
}

func GetUserFines(userID int64) (*FinesSummary, error) {
	rows, err := db.DB.Query(`
		SELECT co.id, b.title, co.due_date, co.returned_at, co.fine_amount, co.fine_paid
		FROM checkouts co
		JOIN book_copies bc ON bc.id = co.copy_id
		JOIN books b ON b.id = bc.book_id
		WHERE co.user_id = ? AND co.fine_amount > 0
		ORDER BY co.due_date DESC`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	summary := &FinesSummary{UserID: userID}
	for rows.Next() {
		var d FineDetail
		var finePaidInt int
		if err := rows.Scan(&d.CheckoutID, &d.BookTitle, &d.DueDate, &d.ReturnedAt,
			&d.FineAmount, &finePaidInt); err != nil {
			return nil, err
		}
		d.FinePaid = finePaidInt == 1
		summary.TotalFines += d.FineAmount
		if d.FinePaid {
			summary.PaidFines += d.FineAmount
		} else {
			summary.UnpaidFines += d.FineAmount
		}
		summary.Details = append(summary.Details, d)
	}
	_ = fmt.Sprintf // avoid unused import
	return summary, rows.Err()
}
